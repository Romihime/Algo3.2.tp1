#include <iostream>
#include <math.h>

using namespace std;

int main(){
	double n;
	double v;
	cin >> n;
	cin >> v;
	while(n!= 0 && v!= 0){
		cout << ( v*n )<< endl;
		for(int i = 0; i < n; i++){
			int aux;
			cin >> aux;
		}
		cin >> n;
		cin >> v;
	}
	return 0;
}