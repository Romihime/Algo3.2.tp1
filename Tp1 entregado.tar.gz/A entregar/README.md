# Algo32cuat2018

Como correr:
Hacer make
Los algoritmos estan comentados para que salga la respuesta, pero para correr tiempos, descomentar el cout de time_span.count() y comentar el otro.
Make test:
Make test llama a generadorDeInputs y este guarda las instancias en "in". Fijarse que se puede ir aumentando n, o v, o dejarlos fijos, etc.
Luego se los hace correr a los algoritmos con las entradas y las sacan a un output.
Este es llamado por plot.py, donde se realizan los graficos.
El archivo ComparativaFuncionesPearson es donde se realizaron los graficos de pearson, con los archivos complejidadbt y pd .cpp donde se hace la multiplicacion por la complejidad teorica.

